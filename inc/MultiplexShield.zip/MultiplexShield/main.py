# Pre-emptive spectral graph protection strategies on multiplex social networks
# Email : ariewahyu@net.c.titech.ac.jp


# Main file

import networkx as nx
import string
import sys
import os
import numpy as np
import timeit
from operator import itemgetter
from scipy.sparse.linalg.eigen.arpack import eigsh as fast_eig
from scipy.sparse import csgraph
from scipy.sparse import csr_matrix
from scipy.sparse import identity
from scipy.sparse import eye
from scipy.sparse import lil_matrix
import scipy.io as sio
import multinetx as mx
import random
from simulation import *


def read_multiplex_graph(filename, M):

	G = [[nx.DiGraph()]]*M
	for i in range(0,M):
		G[i] = nx.DiGraph()

	f = open(os.path.join('.', filename),'r')
	lines = f.readlines()
	node_list = []
	layer_list = []
	edge = 0
	for line in lines:
		[layer, node1, node2, weight]=line.split()
		layer = int(layer)
		node1 = int(node1)
		node2 = int(node2)
		weight = eval(weight)
		node_list.append(node1)
		node_list.append(node2)
		layer_list.append(layer)
		edge = edge + 1
	
	# calculate number of nodes 
	N = max(list(set(node_list))) - min(list(set(node_list))) + 1
	# calculate number of layer 
	M = len(list(set(layer_list)))
	# calculate number of edges 
	E = edge

	for i in range(0,M):
		G[i].add_nodes_from(list(set(node_list)))

	for line in lines:
		[layer, node1, node2, weight]=line.split()
		layer = int(layer)-1
		node1 = int(node1)
		node2 = int(node2)
		weight = eval(weight)
		for i in range(0,M):
			if layer == i: G[i].add_edge(node1, node2, weight=weight)
	
	f.close()

	adj_block = lil_matrix(lil_matrix((N*M,N*M), dtype=np.int8))
	for i in range(0,M):
		# print('i',i)
		for j in range(0,M):
			if i != j:
				adj_block[i*N:(i+1)*N, j*N:(j+1)*N] = eye(N, dtype=np.int8) 

	adj_block += adj_block.T
	
	G = mx.MultilayerGraph(list_of_layers=[G[i] for i in range(0,M)],inter_adjacency_matrix=adj_block)

	return G,N,M,E



# MULTIPLEX BASED METHOD

# MultiplexShield Multiplex based
# M is number of layer
# N is number of nodes
def MultiplexShield_multiplexbased(G, k, M, beta, delta):
	n = nx.number_of_nodes(G)
	N = int(n/M)
	idx = []
	if k<0:
		idx = -1 
	A = nx.to_scipy_sparse_matrix(G, dtype=np.float, format='lil').todense()
	MW = [[lil_matrix((N, N), dtype=np.float)] * M for _ in range(M)]
	xvalue = np.zeros(N)

	for i in range(0,M):
		MW[i]= A[i*N:(i+1)*N, i*N:(i+1)*N]

	for x in range(0,M):
		W = MW[x]
		outd = W.sum(axis=1)
		deg = np.transpose(outd)
		deg = np.array(deg)
		deg = np.diag(deg[0])

		# using randomwalk normalized Laplacian
		D = np.diag((deg + (deg==0))**-1.0)
		L = eye(N) - np.dot(D, W)

		L = L.astype(float)
		vals, vecs = fast_eig(L, 2, which='SA')
		vals = vals[1]
		vecs = vecs[:,1]

		value = np.zeros(N)
		for i in range(0,N):
			for j in range(0,M):
				value[i] = outd[i] * vecs[i] * (beta[j]/delta[j])
				xvalue[i] = xvalue[i] + value[i]

	# pick top k highest value 
	idx = sorted(range(len(xvalue)), key=lambda i: xvalue[i])[-k:]
	
	return idx

# LAYER BASED METHOD
# MultiplexShield Layer based
# M is number of layer
# N is number of nodes
def MultiplexShield_layerbased(G, k, M, beta, delta):
	n = nx.number_of_nodes(G)
	N = int(n/M)
	idx = []
	if k<0:
		idx = -1 
	A = nx.to_scipy_sparse_matrix(G, dtype=np.int8, format='lil').todense()
	outd = A.sum(axis=1)
	MW = [[lil_matrix((N, N), dtype=np.int8)] * M for _ in range(M)]
	xvalue = np.zeros(n)
	fiedler = []

	for i in range(0,M):
		MW[i]= A[i*N:(i+1)*N, i*N:(i+1)*N]

	for x in range(0,M):
		W = MW[x]
		
		deg = np.transpose(W.sum(axis=1))
		deg = np.array(deg)
		deg = np.diag(deg[0])

		# using randomwalk normalized Laplacian
		D = np.diag((deg + (deg==0))**-1.0)
		L = eye(N) - np.dot(D, W)

		L = L.astype(float)
		vals, vecs = fast_eig(L, 2, which='SA')
		vals = vals[1]
		vecs = vecs[:,1]
		fiedler.extend(vecs)


	for i in range(0,N):
		for j in range(0,M):
			xvalue[i+N*j] = outd[i+N*j] * fiedler[i+N*j] * (beta[j]/delta[j])

	# pick top k highest value 
	idx = sorted(range(len(xvalue)), key=lambda i: xvalue[i])[-k:]

	return idx


def evaluate(G, M, type, init, beta, delta):

	n = nx.number_of_nodes(G)
	N = int(n/M)
	
	maxtime = 100
	# iteration = 3

	if type == 'multiplex': upperbound = N
	else : upperbound = n

	s_data = []
	r_data = []
	
	for k in range(0,upperbound):
		if k==0: k = 1
		numseed = k;

		# Multiplex Based
		idx = MultiplexShield_multiplexbased(G, k, M, beta, delta); 

		# Layer Based
		idx = MultiplexShield_layerbased(G, k, M, beta, delta); 

		if type == 'multiplex': 
			survival, ratio = simulation_multiplexbased(G, M, idx, init, numseed, maxtime, beta, delta, [])
		else : 
			survival, ratio = simulation_layerbased(G, M, idx, init, numseed, maxtime, beta, delta, [])
		s_data.append(survival[-1]) 
		r_data.append(ratio[-1]) 

	return r_data


def main():
	filename = sys.argv[1]
	M = int(sys.argv[2])

	G,N,M,E = read_multiplex_graph(filename, M)

	beta = [0.5, 0.6]
	delta = [0.5, 0.6]
	init = 'high-degree'
	k = 4 
	type = 'multiplex'
	result= evaluate(G, M, type, init, beta, delta);
	print(result);
	

if __name__=='__main__':
    main()
