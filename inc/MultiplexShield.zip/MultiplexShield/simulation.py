# Pre-emptive spectral graph protection strategies on multiplex social networks
# Email : ariewahyu@net.c.titech.ac.jp

import networkx as nx
import numpy as np
from operator import itemgetter
from scipy.sparse.linalg.eigen.arpack import eigsh as fast_eig
from scipy.sparse import csgraph
from scipy.sparse import csr_matrix
from scipy.sparse import identity
from scipy.sparse import eye
from scipy.sparse import lil_matrix
import scipy.io as sio
import random

# Simulation of Attack
# Multiplex Based
# M is number of layers
# N is number of nodes in each layer
# n is number of all nodes
def simulation_multiplexbased(G, M, idx, init, numseed, maxtime, beta, delta, seednodes):
	# All of protected nodes will also be protected in all of their corresponding layers.
	# All of infected nodes will also be infected in all of their corresponding layers. 

	n = nx.number_of_nodes(G)
	k = numseed
	N = int(n/M)
	# A = nx.to_scipy_sparse_matrix(G, dtype=np.int8).todense()
	A = nx.to_scipy_sparse_matrix(G, dtype=np.int8, format='lil')
	# MW = [[lil_matrix((N, N), dtype=np.int8)] * M for _ in range(M)]

	# for i in range(0,M):
	# 	MW[i]= A[i*N:(i+1)*N, i*N:(i+1)*N]

	survival = []
	ratio = []

	active = np.arange(n)

	# % protecting selected nodes from Graph
	# the protected nodes can not get infected in all layers
	temp = A.todense()
	for i in range(0,M):
		for j in idx:
			temp[:,i*N+j] = 0
			temp[i*N+j,:] = 0
		G = temp
	survival.extend([n])
	ratio.extend([1])

	# initialize seednodes for virus
	# uncomment this line for attacking strategy excluding currently protected nodes
	# target = active(~ismember(active,idx));

	# for attacking strategy including currently protected nodes
	target = active;
	protected = []
	for i in range(0,M):
		for j in idx:
			protected.extend([i*N+j])
	if not seednodes:
		if init=='random':
			infected = target[np.random.choice(len(target), numseed, replace=False)]
		elif init=='high-degree':
			G[G != 0] = 1
			degree = G.sum(axis=1)

			# pick top 2*numseed highest value of degree
			infected = sorted(range(len(degree)), key=lambda i: degree[i])[-(2*numseed):]
			
			# the protected nodes can not be infected
			infected = [int(x) for x in infected if x not in idx]
			infected = infected[-numseed:]

		elif init=='given':
			infected = seednodes
		else:
			infected = target[np.random.choice(len(target), numseed, replace=False)]
	else:
		infected = seednodes

	failed = infected;
	neighbor = np.array([])
	graph = nx.from_scipy_sparse_matrix(A,create_using=nx.DiGraph())
	for z in range(0,maxtime):
		# infection
		# target is the neighbor, check the out degree of each infected nodes
		# out degree: see row of adjacency matrix
		# in degree: see column of adjacency matrix
		# neighbor = target(~ismember(target,failed));
		# remove duplicates in neighbor
		for j in range(0,len(infected)):
			# uncomment next line for Networkx 1.x version
			# neighbor = np.append(neighbor,graph.neighbors(infected[j]))
			# for Networkx 2.x version
			neighbor = np.append(neighbor,list(graph.neighbors(infected[j])))

		# the protected nodes can not be infected
		neighbor = [int(x) for x in neighbor if x not in protected]
		neighbor = list(set(neighbor))

		layer = [[0]*N for _ in range(N)]
		for i in range(0,M):
			layer[i] =  [x for x in neighbor if x > i*N and x <= (i+1)*N]
			layer[i] = list(set(layer[i]))

		# layer = [[0]*N for _ in range(N)]
		# for i in range(0,M):
		# 	layer[i] =  neighbor[(neighbor > i*N)   & (neighbor <= (i+1)*N)]
		# 	layer[i] = list(map(int, layer[i]))

		# apply infection rate
		infected = []
		for i in range(0,M):
			infected.extend(np.unique(random.sample(layer[i], int(round(beta[i]*len(layer[i]),0)))))


		failed = np.append(failed,infected)
		# remove duplicates in failed nodes
		failed = np.unique(failed)

		layer = [[0]*N for _ in range(N)]
		for i in range(0,M):
			layer[i] =  failed[(failed > i*N)   & (failed <= (i+1)*N)]
			layer[i] = list(map(int, layer[i]))

		# apply host recovery rate
		recovered = []
		for i in range(0,M):
			recovered.extend(np.unique(random.sample(layer[i], int(round(delta[i]*len(layer[i]),0)))))

		# remove recovered host from failed nodes
		tmp = np.array([])
		for i in recovered:
			tmp = np.append(tmp,np.where(failed==i)[0])
		tmp = tmp.astype(int)
		# remove the protected nodes from target of infection
		failed = np.delete(failed,tmp)
		survival.extend([n-len(failed)])
		ratio.extend([(n-len(failed))*1.0/n])
		infected = failed
		

	return survival, ratio



# Simulation of Attack
# Layer Based
def simulation_layerbased(G, M, idx, init, numseed, maxtime, beta, delta, seednodes):

	n = nx.number_of_nodes(G)
	N = int(n/M)
	A = nx.to_scipy_sparse_matrix(G, format='lil', dtype=np.int8)
	survival = []
	ratio = []

	active = np.arange(n)

	# % protecting selected nodes from Graph
	temp = nx.adjacency_matrix(G).todense()
	for i in idx:
		temp[:,i] = 0
		temp[i,:] = 0
	G = temp
	survival.extend([n])
	ratio.extend([1])

	# initialize seednodes for virus
	# uncomment this line for attacking strategy excluding currently protected nodes
	# target = active(~ismember(active,idx));

	# for attacking strategy including currently protected nodes
	target = active;
	protected = idx

	if not seednodes:
		if init=='random':
			infected = target[np.random.choice(len(target), numseed, replace=False)]
		elif init=='high-degree':
			G[G != 0] = 1
			degree = G.sum(axis=1)

			# pick top 2*numseed highest value of degree
			infected = sorted(range(len(degree)), key=lambda i: degree[i])[-(2*numseed):]

			# the protected nodes can not be infected
			infected = [int(x) for x in infected if x not in idx]
			infected = infected[-numseed:]

		elif init=='given':
			infected = seednodes
		else:
			infected = target[np.random.choice(len(target), numseed, replace=False)]
	else:
		infected = seednodes


	failed = infected;
	neighbor = np.array([])
	graph = nx.from_scipy_sparse_matrix(A,create_using=nx.DiGraph())
	for z in range(0,maxtime):
		# infection
		# target is the neighbor, check the out degree of each infected nodes
		# out degree: see row of adjacency matrix
		# in degree: see column of adjacency matrix
		# neighbor = target(~ismember(target,failed));
		# remove duplicates in neighbor
		for j in range(0,len(infected)):
			# uncomment next line for Networkx 1.x version
			# neighbor = np.append(neighbor,graph.neighbors(infected[j]))
			# for Networkx 2.x version
			neighbor = np.append(neighbor,list(graph.neighbors(infected[j])))

		# the protected nodes can not be infected
		neighbor = [int(x) for x in neighbor if x not in protected]
		neighbor = list(set(neighbor))

		layer = [[0]*N for _ in range(N)]
		for i in range(0,M):
			layer[i] =  [x for x in neighbor if x > i*N and x <= (i+1)*N]
			layer[i] = list(set(layer[i]))

		# apply infection rate
		infected = []
		for i in range(0,M):
			infected.extend(np.unique(random.sample(layer[i], int(round(beta[i]*len(layer[i]),0)))))


		failed = np.append(failed,infected)
		# remove duplicates in failed nodes
		failed = np.unique(failed)

		layer = [[0]*N for _ in range(N)]
		for i in range(0,M):
			layer[i] =  failed[(failed > i*N)   & (failed <= (i+1)*N)]
			layer[i] = list(map(int, layer[i]))

		# apply host recovery rate
		recovered = []
		for i in range(0,M):
			recovered.extend(np.unique(random.sample(layer[i], int(round(delta[i]*len(layer[i]),0)))))

		# remove recovered host from failed nodes
		tmp = np.array([])
		for i in recovered:
			tmp = np.append(tmp,np.where(failed==i)[0])
		tmp = tmp.astype(int)
		# remove the protected nodes from target of infection
		failed = np.delete(failed,tmp)
		survival.extend([n-len(failed)])
		ratio.extend([(n-len(failed))*1.0/n])
		infected = failed
	
	return survival, ratio

