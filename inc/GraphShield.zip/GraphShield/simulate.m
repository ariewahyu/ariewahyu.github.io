function [survival, ratio] = simulation(G, idx, init, numseed, maxtime, b, d, seednodes)
% Fuction:
%		Simulate the virus spreading using different immunization strategy and virus initialization type 
% Input:
% 		G			: adjacency matrix of the given Graoh.
% 		idx			: set of nodes that being protected
% 		init		: type of initial virus attacking nodes selection (random or high degree)
% 		seed		: number of initial nodes attacked by virus  
% 		maxtime		: maximum time limit
% 		b			: infection rate
% 		d			: host recovery rate

% Output:
% 		survival	: list of number of nodes that survive in each time step
% 		ratio		: list of ratio of nodes that survive in each time step


% preparing list of survival and ratio value
survival = [];
ratio = [];

% number of nodes
n = size(G,1);
active = [1:n]';

% protecting selected nodes from Graph
k = numel(idx);
temp = G;
for i =1:k
    temp(:,i) = 0;
    temp(i,:) = 0;
end
G = temp;
survival = [survival;n];
ratio = [ratio;1];

% initialize seednodes for virus
% uncomment this line for attacking strategy excluding currently protected nodes
% target = active(~ismember(active,idx));

% for attacking strategy including currently protected nodes
target = active;

if isempty(seednodes)
	switch init
		case 'random'
			infected = target(randperm(length(target),numseed));
		
		case 'high-degree'
			G(G~=0)=1;
			if G==transpose(G)
				deg = sum(G); 					% undirected
			else
				deg = sum(G,1) + sum(G,2)';     % directed: degree = indegree+outdegree
			end
			[sorted,index] = sort(deg,'descend');
			index = index(~ismember(index,idx));
			infected = transpose(index(1:numseed));
		
		case 'given'
			infected = seednodes;

		otherwise
			infected = target(randperm(length(target),numseed));
	end
else
	infected = seednodes;
end
failed = infected;
neighbor = [];
for i=1:maxtime
	% infection
	% target is the neighbor, check the out degree of each infected nodes
	% out degree: see row of adjacency matrix
	% in degree: see column of adjacency matrix
	% neighbor = target(~ismember(target,failed));
	for j=1:length(infected)
		neighbor = [neighbor;find(G(infected(j),:))'];
	end
	% remove duplicates in neighbor
	neighbor = unique(neighbor);
	% apply infection rate
	infected = neighbor(randperm(length(neighbor),round(b*length(neighbor))));
	failed = [failed;infected];
	% remove duplicates in failed nodes
	failed = unique(failed);


	% host recovery
	recovered = failed(randperm(length(failed),round(d*length(failed))));
	% remove recovered host from failed nodes
	failed = failed(~ismember(failed,recovered));

	r = length(failed)/n;
	survival = [survival;n-length(failed)];
	ratio = [ratio;r];
	infected = failed;
end


end
