% Effectiveness Evaluation

clear all
clc

% load dataset
load citeseer.mat; 

% parameter setting for immunization strategy
k = round(size(G,1)/10); 
eigtype = 'lr'; 

% parameter setting for virus propagation simulation
init = 'random'; numseed = k; maxtime = 100; b = 0.9; d = 0.6;

% perform immunization strategy
[idx] = graphshield(G,k,eigtype);

% perform simulation on virus propagation model
[s, r] = simulate(G, idx, init, numseed, maxtime, b, d, []); 