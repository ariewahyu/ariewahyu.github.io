function [idx] = grapshield(A,k,eigtype)
% Fuction:
%		GraphShield, a fast and scalable method for Flow-Aware Vertex Protection (FAVP) problem   
% Input:
% 		A			: adjacency matrix of the given Graoh.
% 		k			: set of nodes that will be protected
% 		eigtype		: the type of eigen-value ('lm', 'sm', 'la' (default), 'sa', 'be', 'lr', 'sr', 'li', 'si', scalar). We mostly use 'lr'

% Output:
% 		idx			: the index of selected nodes

if k<0
    idx = -1;
    return;
end

opts.disp = 0;

% Largest eigenvalue        
degs = sum(A, 2);
outdeg = full(degs);
[u, lambda] = eigs(A, 1,eigtype,opts);
lambda = real(lambda);
u = real(u);

xvalue = abs(real(u) .* outdeg);
xvalue(xvalue==0) = -inf;         
[val ind] = sort(xvalue,'descend') ; % select k highest
idx = ind(1:k);
